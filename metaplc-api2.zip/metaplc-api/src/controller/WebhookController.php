<?php
namespace src\controller;

use GuzzleHttp\Client;

class WebhookController {

    private $requestMethod;

    public function __construct($requestMethod)
    {
        $this->requestMethod = $requestMethod;
    }

    public function processRequest()
    {
        switch ($this->requestMethod) {
            case 'GET':
                $response = $this->index();
                break;
            case 'POST':
                $response = $this->post();
                break;
            case 'PUT':
            case 'DELETE':
            default:
                $response = $this->notFoundResponse();
                break;
        }
        header($response['status_code_header']);
        if ($response['body']) {
            echo $response['body'];
        }
    }

    private function index()
    {
        die('hello');
    }


    // {
    //     "flowId": "",
    //     "flowName": "",
    //     "stepName": "",
    //     "stepConversion": "",
    //     "contacts": [
    //         {
    //             "customerId": "",
    //             "contactEmail": "",
    //             "contactPhone": "",
    //             "contactName": "",
    //             "contactFirstName": "",
    //             "contactLastName": "",
    //             "enrichments": [
    //                 {
    //                     "objectType": "M-3WC4O-O-BGKOG-M",
    //                     "objectType2": "",
    //                     "maxRecords": 123,
    //                     "matchingFields": [],
    //                     "objects": [
    //                         {
    //                             "id": "",
    //                             "refId": "{refId}",
    //                             "customerId": "",
    //                             "customerEmail": "",
    //                             "customerPhone": "",
    //                             "zoaId": "",
    //                             "zoaUserId": "",
    //                             "cardStars": 123,
    //                             "productQuality": 123,
    //                             "customerStaff": 123,
    //                             "storeSpace": 123,
    //                             "deliveryTime": 123,
    //                             "fullName": "",
    //                             "improveNote": "",
    //                             "storeName": "",
    //                             "saleStaff": "",
    //                             "orderCode": "",
    //                             "cashier": "",
    //                             "tags": [
    //                                 "tag1",
    //                                 "tag2"
    //                             ]
    //                         }
    //                     ]
    //                 }
    //             ],
    //             "success": true,
    //             "message": ""
    //         }
    //     ]
    // }
    private function post()
    {
        $input = (array) json_decode(file_get_contents('php://input'), TRUE) ?: [];
        
        $flowId = $input["flowId"];
        $flowName = $input["flowName"];
        $stepName = $input["stepName"];
        $stepConversion = $input["stepConversion"];
        $contacts = $input["contacts"] ?: [];

        if(count($contacts) > 0){
            foreach ($contacts as $contact) {
                # code...
                $customerId = $contact["customerId"];
                $contactEmail = $contact["contactEmail"];
                $contactPhone = $contact["contactPhone"];
                $contactName = $contact["contactName"];
                $contactFirstName = $contact["contactFirstName"];
                $contactLastName = $contact["contactLastName"];
                $enrichments = $contact["enrichments"];

                if(count($enrichments) > 0){
                    foreach ($enrichments as $enrichment) {
                        $objectType = $enrichment["objectType"];
                        $objectType2 = $enrichment["objectType2"];
                        $maxRecords = $enrichment["maxRecords"];
                        $matchingFields = $enrichment["matchingFields"];
                        $objects = $enrichment["objects"];
    
                        if(count($objects) > 0){
                            foreach ($objects as $object) {
                                $id = $object["id"];
                                $refId = $object["refId"];
                                $customerId = $object["customerId"];
                                $customerEmail = $object["customerEmail"];
                                $customerPhone = $object["customerPhone"];
                                $zoaId = $object["zoaId"];
                                $zoaUserId = $object["zoaUserId"];
                                $cardStars = $object["cardStars"];
                                $productQuality = $object["productQuality"];
                                $customerStaff = $object["customerStaff"];
                                $storeSpace = $object["storeSpace"];
                                $deliveryTime = $object["deliveryTime"];
                                $fullName = $object["fullName"];
                                $improveNote = $object["improveNote"];
                                $storeName = $object["storeName"];
                                $saleStaff = $object["saleStaff"];
                                $orderCode = $object["orderCode"];
                                $cashier = $object["cashier"];
                                $tags = $object["tags"];
                            }
                        }
                    }
                }
            }
        }

        $response = $this->__createNewPost();
        ob_start();
        var_dump($response);
        $dump = ob_get_clean();
        echo '<pre>' . preg_replace('/\]\=\>\n(\s+)/m', '] => ', $dump) . '</pre>';
        die;
    
        $response['status_code_header'] = 'HTTP/1.1 201 Created';
        $response['body'] = null;
        return $response;
    }

    const BASE_URI = "graph.facebook.com";
    const DEF_GRPID = "1326195084820814";
    const ACCESS_TOKEN = "DQVJzWXM1ZAlMxMHVCeERqNDJteFhlN3RMeGNFbkM2VVY3TENiS2wwSXc5YmZAMUmE5b3FUNy1kcl95WVVLNTQ2bGhsMThJTnVmMXZAJSEVia2hNVGVKdFlESHplNEJicG82aGtmWG5SVTExbUFSLUg1SUJ1NUR5RGlVQVBDU3cteFJlczdWdWR4US1yMXpLclFJazVGdEZANRnY2N3FiZADVtQ3dSN1loMnBNaGJhOFVoN1FROVphMVgzRHVuWVpacTJLaU1ZAWFZAR";

    private function __createNewPost(){
        $client = new Client();
        $response = $client->post(self::BASE_URI . '/'.self::DEF_GRPID.'/feed', [
            'query' => [
                "message" => "Post new in ".((new \DateTime("now"))->format("F d Y H:i:s")),
                "link" => "https://developers.facebook.com/docs/workplace/custom-integrations/apps#2",
                "access_token" => self::ACCESS_TOKEN
            ],
            'allow_redirects'=> ['strict'=>true]
        ]);

        return $response->getBody() ? json_decode($response->getBody()->getContents()) : [];
    }

    private function unprocessableEntityResponse()
    {
        $response['status_code_header'] = 'HTTP/1.1 422 Unprocessable Entity';
        $response['body'] = json_encode([
            'error' => 'Invalid input'
        ]);
        return $response;
    }

    private function notFoundResponse()
    {
        $response['status_code_header'] = 'HTTP/1.1 404 Not Found';
        $response['body'] = null;
        return $response;
    }

}