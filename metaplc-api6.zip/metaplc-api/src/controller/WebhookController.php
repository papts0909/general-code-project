<?php
namespace src\controller;

use DateTime;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;
use GuzzleHttp\Exception\ClientException;
use GuzzleHttp\Exception\ServerException;

class WebhookController {

    const BASE_URI = "graph.facebook.com";
    const DEF_GRPID = "1326195084820814";
    const META_ACCESS_TOKEN = "DQVJzWXM1ZAlMxMHVCeERqNDJteFhlN3RMeGNFbkM2VVY3TENiS2wwSXc5YmZAMUmE5b3FUNy1kcl95WVVLNTQ2bGhsMThJTnVmMXZAJSEVia2hNVGVKdFlESHplNEJicG82aGtmWG5SVTExbUFSLUg1SUJ1NUR5RGlVQVBDU3cteFJlczdWdWR4US1yMXpLclFJazVGdEZANRnY2N3FiZADVtQ3dSN1loMnBNaGJhOFVoN1FROVphMVgzRHVuWVpacTJLaU1ZAWFZAR";
    const ACCESS_TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6Ik1hcmMgTmdvIiwiaWF0IjoxNjY4NTYzMDc1fQ.9TMRcfql-tRVuWlI1cZx6h8eTX9gNgZU_INgcN2y5_4";

    private $requestMethod;

    public function __construct($requestMethod){
        $this->requestMethod = $requestMethod;
    }

    public function processRequest(){
        switch ($this->requestMethod) {
            case 'GET':
                $response = $this->index();
                break;
            case 'POST':
                $response = $this->post();
                break;
            case 'PUT':
            case 'DELETE':
            default:
                $response = $this->notFoundResponse();
                break;
        }
        header($response['status_code_header']);
        if ($response['body']) {
            echo $response['body'];
        }
    }

    private function index(){
        // echo json_encode(["status" => "OK","message" => "hello"]);
        // $response['status_code_header'] = 'HTTP/1.1 200 OK';
        // $response['body'] = null;
        // return $response;
        header("Content-Type: text/html; charset=UTF-8");
        $log_directory = __DIR__."\..\..\public\storage\log_request";

        $files = array_diff(scandir($log_directory), array('.', '..'));
        rsort($files);
        //Output findings
        foreach($files as $value)
        {
            $time =  str_replace('.txt', '', $value);
            if(!is_numeric($time) && $time <= 0){
                continue;
            }
            echo '<a target="_blank" href="'.$_SERVER["HTTP_HOST"]."/storage/log_request/".$value.'">'.date("Y-m-d H:i:s",$time) . '</a><br />';
        }
        die;
    }

    // {
    //     "flowId": "",
    //     "flowName": "",
    //     "stepName": "",
    //     "stepConversion": "",
    //     "contacts": [
    //         {
    //             "customerId": "",
    //             "contactEmail": "",
    //             "contactPhone": "",
    //             "contactName": "",
    //             "contactFirstName": "",
    //             "contactLastName": "",
    //             "enrichments": [
    //                 {
    //                     "objectType": "M-3WC4O-O-BGKOG-M",
    //                     "objectType2": "",
    //                     "maxRecords": 123,
    //                     "matchingFields": [],
    //                     "objects": [
    //                         {
    //                             "id": "",
    //                             "refId": "{refId}",
    //                             "customerId": "",
    //                             "customerEmail": "",
    //                             "customerPhone": "",
    //                             "zoaId": "",
    //                             "zoaUserId": "",
    //                             "cardStars": 123,
    //                             "productQuality": 123,
    //                             "customerStaff": 123,
    //                             "storeSpace": 123,
    //                             "deliveryTime": 123,
    //                             "fullName": "",
    //                             "improveNote": "",
    //                             "storeName": "",
    //                             "saleStaff": "",
    //                             "orderCode": "",
    //                             "cashier": "",
    //                             "tags": [
    //                                 "tag1",
    //                                 "tag2"
    //                             ]
    //                         }
    //                     ]
    //                 }
    //             ],
    //             "success": true,
    //             "message": ""
    //         }
    //     ]
    // }
    private function post(){

        $input = (array) json_decode(file_get_contents('php://input'), TRUE) ?: [];
        $accessToken = $_GET["access_token"];

        if($accessToken != self::ACCESS_TOKEN){
            echo json_encode(["status" => "UNAUTHORIZED"]);
            return [
                'status_code_header' => 'HTTP/1.1 401 Unauthorized',
                'body' => null
            ];
        }

        if(count($input) < 0 || !$input){
            echo json_encode(["status" => "POST_DATA_NOT_FOUND"]);
            return [
                'status_code_header' => 'HTTP/1.1 400 Bad Request',
                'body' => null
            ];
        }
        
        $data = $this->mappingData($input) ?: [];

        if(count($data) > 0){
            foreach ($data as $key => $item) {
                if($item["message"] && $item["message"] != ""){
                    $this->__createNewPost($item);
                }
            }
        }

        echo json_encode(["status" => "OK"]);
        $response['status_code_header'] = 'HTTP/1.1 201 Created';
        $response['body'] = null;
        return $response;
    }

    /**
     * "Có khách hàng đã đánh giá sau bán hàng <=3* với nội dung như sau 
     * Khách hàng (id-ref-id-customer-id-customeremail-customerphone-contactEmail-contactPhone-contactName-contactFirstName-contactLastName)
     * Zalo (zoaid-zoauserid)
     * Đánh giá * (cardstars-productQuality)
     * Ý kiến (ImproveNote)
     * NVBH-Cửa hàng (CustomerStaff-StoreSpace-DeliveryTime-Fullname-StoreName-SalesStaff-OrderCode-Cashier)"
     */
    private function mappingData($data){
 
        $messageArrays = [];
        $places = [];

        $flowId = $data["flowId"];
        $flowName = $data["flowName"];
        $stepName = $data["stepName"];
        $stepConversion = $data["stepConversion"];
        $contacts = $data["contacts"] ?: [];

        if(count($contacts) > 0){
            foreach ($contacts as $contact) {
                $customerId = $contact["customerId"];
                $contactEmail = $contact["contactEmail"];
                $contactPhone = $contact["contactPhone"];
                $contactName = $contact["contactName"];
                $contactFirstName = $contact["contactFirstName"];
                $contactLastName = $contact["contactLastName"];
                $enrichments = $contact["enrichments"];

                if(count($enrichments) > 0){
                    foreach ($enrichments as $enrichment) {
                        $objectType = $enrichment["objectType"];
                        $objectType2 = $enrichment["objectType2"];
                        $maxRecords = $enrichment["maxRecords"];
                        $matchingFields = $enrichment["matchingFields"];
                        $objects = $enrichment["objects"];
    
                        if(count($objects) > 0){
                            $messageArray = [
                                "customerName" => [
                                    "label" => "Khách hàng",
                                    "value" => ""
                                ],
                                "zalo" => [
                                    "label" => "Zalo",
                                    "value" => ""
                                ],
                                "rating" => [
                                    "label" => "Đánh giá",
                                    "value" => ""
                                ],
                                "comment" => [
                                    "label" => "Ý kiến",
                                    "value" => ""
                                ],
                                "customerStaff" => [
                                    "label" => "NVBH-Cửa hàng",
                                    "value" => ""
                                ]
                            ];
                    
                            foreach ($objects as $object) {
                                $id = $object["id"];
                                $refId = $object["refId"];
                                $customerId = $object["customerId"];
                                $customerEmail = $object["customerEmail"];
                                $customerPhone = $object["customerPhone"];
                                $zoaId = $object["zoaId"];
                                $zoaUserId = $object["zoaUserId"];
                                $cardStars = $object["cardStars"];
                                $productQuality = $object["productQuality"];
                                $customerStaff = $object["customerStaff"];
                                $storeSpace = $object["storeSpace"];
                                $deliveryTime = $object["deliveryTime"];
                                $fullName = $object["fullName"];
                                $improveNote = $object["improveNote"];
                                $storeName = $object["storeName"];
                                $saleStaff = $object["saleStaff"];
                                $orderCode = $object["orderCode"];
                                $cashier = $object["cashier"];
                                $tags = $object["tags"];
                                
                                $messageArray["customerName"]["value"] = "{$id}-{$$refId}-{$customerId}-{$customerEmail}-{$customerPhone}-{$contactEmail}-${$contactPhone}-{$contactName}-{$contactFirstName}-{$contactLastName}";
                                $messageArray["zalo"]["value"] ="{$zoaId}-{$zoaUserId}";
                                $messageArray["rating"]["value"] = "{$cardStars}-{$productQuality}";
                                $messageArray["comment"]["value"] = "{$improveNote}";
                                $messageArray["customerStaff"]["value"] = "{$customerStaff}-{$storeSpace}-{$deliveryTime}-{$fullName}-{$storeName}-{$saleStaff}-{$orderCode}-{$cashier}";

                                $message = "";
                                foreach($messageArray as $key => $item) {
                                    $message .= "* ".$item["label"].": ".$item["value"]."\n\n";
                                }
                                if($message != ""){
                                    if($customerId){
                                        $messageArrays[$customerId][] = "## **THÔNG TIN PHẢN HỒI KHÁCH HÀNG** \n".$message;
                                    }else{
                                        $messageArrays[-1][] = "## **THÔNG TIN PHẢN HỒI KHÁCH HÀNG** \n".$message;
                                    }
                                }

                                $places[] = $storeName;
                            }
                        }
                    }
                }
            }
        }

        $templateResult = [
            "icon" => "https://theme.hstatic.net/1000184601/1000882765/14/profile_logo_7.jpg?v=2283",
            "link" =>  "",
            "message" => "",
            "name" => "CSKH"
        ];

        $result = [];

        if(count($messageArrays) > 0){
            foreach ($messageArrays as $customerId => $messageArray) {
                foreach ($messageArray as $message) {
                    if(!$result[$customerId]){
                        $result[$customerId] = array_merge($templateResult,["message" => $message]);
                    }else{
                        $result[$customerId]["message"] .= "\n".$message;
                    }
                }
            }
        }

        return $result;

        // return [
        //     "icon" => "http://2ndhost.byethost9.com/public/1.ico",
        //     "link" =>  "",
        //     "message" => count($messageArrays) > 0 ? implode("\n",$messageArrays) : "",
        //     "name" => "CSKH"
        // ];
    }

    private function __createNewPost($data){
        try {
            $client = new Client();
            $response = $client->post(self::BASE_URI . '/'.self::DEF_GRPID.'/feed', [
                'query' => [
                    // "message" => "Post new in ".((new \DateTime("now"))->format("F d Y H:i:s")),
                    // "link" => "https://developers.facebook.com/docs/workplace/custom-integrations/apps#2",
                    "icon"         => $data["icon"],
                    // "link"         => $data["link"],
                    "message"      => $data["message"],
                    "name"         => $data["name"],
                    // "place"        => $data["place"],
                    "formatting"   => "MARKDOWN",
                    "access_token" => self::META_ACCESS_TOKEN
                ],
                'allow_redirects'=> ['strict'=>true]
            ]);
    
            return $response->getBody() ? json_decode($response->getBody()->getContents()) : [];

        } catch (\Exception $e) {
            $res = $e->getMessage();
        } catch (RequestException $e) {
            $res = $e->getResponse();
        } catch (ClientException $exception) {
            $res = $exception->getResponse()->getBody(true);
        } catch (ServerException $exception) {
            $res = $exception->getResponse()->getBody(true);
        }
        ob_start();
        var_dump($res);
        $dump = ob_get_clean();
        echo '<pre>' . preg_replace('/\]\=\>\n(\s+)/m', '] => ', $dump) . '</pre>';
        die;
    }

    private function unprocessableEntityResponse(){
        $response['status_code_header'] = 'HTTP/1.1 422 Unprocessable Entity';
        $response['body'] = json_encode([
            'error' => 'Invalid input'
        ]);
        return $response;
    }

    private function notFoundResponse(){
        $response['status_code_header'] = 'HTTP/1.1 404 Not Found';
        $response['body'] = null;
        return $response;
    }
}